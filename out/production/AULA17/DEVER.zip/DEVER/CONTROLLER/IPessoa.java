package DEVER.CONTROLLER;

public interface IPessoa   {
   public void cadastra();
   public void imprime();
}
