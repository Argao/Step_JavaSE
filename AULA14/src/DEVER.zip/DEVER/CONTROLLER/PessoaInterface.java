package DEVER.CONTROLLER;

public interface PessoaInterface {
    public void cadastra();
    public void imprime();

}
