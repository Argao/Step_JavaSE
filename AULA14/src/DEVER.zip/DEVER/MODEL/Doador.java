package DEVER.MODEL;

public class Doador extends Pessoa{

    public Doador(String nome,String cpf, String telefone, String sangue) {
        super(nome,cpf, telefone, sangue);
    }

    public Doador() {
    }
}
