package DEVER.MODEL;

public class NaoDoador extends Pessoa{


    public NaoDoador(String nome, String cpf, String telefone, String sangue) {
        super(nome, cpf, telefone, sangue);
    }

    public NaoDoador() {
    }
}
